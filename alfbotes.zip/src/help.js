const help = (prefix) => {
	return `
┏ ❣         *RYOBOT*         ❣
╿
┷┯ ☾ Group Commands ☽
   ╽
   ┠❥ *${prefix}add [Nomor]*
   ┠❥ *${prefix}kick @tagmember*
   ┠❥ *${prefix}tagall*
   ┠❥ *${prefix}listadmins*
   ┠❥ *${prefix}welcome [1/0]*
   ┠❥ *${prefix}linkgroup*
   ╿
┷┯ ☾ Others Commands ☽
   ╽
   ┠❥ *${prefix}sticker / stiker*
   ┠❥ *${prefix}sticker nobg*
   ┠❥ *${prefix}toimg*
   ┠❥ *${prefix}tts [cc] [text]*
   ┠❥ *${prefix}stiker*
   ┠❥ *${prefix}loli*
   ┠❥ *${prefix}memeindo*
   ┠❥ *${prefix}meme*
   ┠❥ *${prefix}wait*
   ┠❥ *${prefix}nulis [Text]*
   ┠❥ *${prefix}ocr*
   ╿

┷┯ ☾ Owner Command ☽
   ╽
   ┠❥ *${prefix}setprefix*
   ╿
   ╰╼❥ *RYOBOT*
}

exports.help = help
